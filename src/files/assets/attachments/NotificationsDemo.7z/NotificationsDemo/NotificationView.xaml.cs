﻿using System.Windows.Controls;
using System.Windows.Input;

namespace NotificationsDemo
{
	public partial class NotificationView : UserControl
	{
		public NotificationView()
		{
			InitializeComponent();
		}

		private void Border_MouseEnter(object sender, MouseEventArgs e)
		{
			((NotificationViewModel) DataContext).IsMouseOver = true;
		}

		private void Border_MouseLeave(object sender, MouseEventArgs e)
		{
			((NotificationViewModel) DataContext).IsMouseOver = false;
		}

		private void UserControl_Loaded(object sender, System.Windows.RoutedEventArgs e)
		{
			((NotificationViewModel) DataContext).Activate();
		}
	}
}
