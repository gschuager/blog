﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace NotificationsDemo
{
	public static class Execute
	{
		private static readonly ExpressionType[] ValidExpressionTypes =
			new[]
				{
					ExpressionType.Equal, ExpressionType.NotEqual,
					ExpressionType.GreaterThan,
					ExpressionType.GreaterThanOrEqual,
					ExpressionType.LessThan,
					ExpressionType.LessThanOrEqual
				};

		public static void NowOrWhenBecomesTrue(Expression<Func<bool>> condition, Action action)
		{
			var compiledCondition = condition.Compile();
			
			if (compiledCondition())
			{
				action();
				return;
			}

			var binaryExpression = condition.Body as BinaryExpression;
			if (binaryExpression == null)
				throw new ArgumentException("must be a binary expression", "condition");

			if (ValidExpressionTypes.Any(t => t == binaryExpression.NodeType) == false)
				throw new ArgumentException("expression is invalid, it must be ==, !=, >, >=, < or <=");

			var memberExpression = binaryExpression.Left as MemberExpression;
			if (memberExpression == null)
				throw new ArgumentException("left side of expression must be a property access", "condition");

			var propertyName = memberExpression.Member.Name;

			var inpc = GetHostFromExpression(memberExpression.Expression) as INotifyPropertyChanged;
			if (inpc == null)
				throw new ArgumentException("cannot determine INotifyPropertyChanged implementor to watch", "condition");

			PropertyChangedEventHandler handler = null;
			handler = (s, e) =>
			          	{
							if (e.PropertyName == propertyName)
			          		{
								if (compiledCondition())
								{
									action();
									inpc.PropertyChanged -= handler;
								}
			          		}
			          	};

			inpc.PropertyChanged += handler;
		}

		private static object GetHostFromExpression(Expression expression)
		{
			if (expression.NodeType == ExpressionType.Constant)
				// case with "this" pointer
				return ((ConstantExpression)expression).Value;
			
			if (expression.NodeType == ExpressionType.MemberAccess)
				// case when accessing a property of an object other than "this"
				return GetObjectFromMemberExpression((MemberExpression)expression);

			return null;
		}

		private static object GetObjectFromMemberExpression(MemberExpression memberExpression)
		{
			var memberAccessor = memberExpression.Member;
			var host = GetHostFromExpression(memberExpression.Expression);
			return host == null ? null : GetObjectFromMember(memberAccessor, host);
		}

		private static object GetObjectFromMember(MemberInfo memberInfo, object host)
		{
			switch (memberInfo.MemberType)
			{
				case (MemberTypes.Property):
					return ((PropertyInfo) memberInfo).GetValue(host, null);
				case (MemberTypes.Field):
					return ((FieldInfo) memberInfo).GetValue(host);
			}
			return null;
		}
	}
}