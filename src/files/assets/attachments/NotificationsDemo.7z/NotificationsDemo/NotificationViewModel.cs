﻿using System;
using System.ComponentModel;
using System.Windows.Threading;

namespace NotificationsDemo
{
	public class NotificationViewModel : INotifyPropertyChanged
	{
		private bool isMouseOver;
		private DispatcherTimer timer;

		public bool IsMouseOver
		{
			get { return isMouseOver; }
			set
			{
				isMouseOver = value;
				NotifyOfPropertyChanged("IsMouseOver");
			}
		}

		public string Text { get; set; }

		private void NotifyOfPropertyChanged(string propertyName)
		{
			PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
		}

		public event PropertyChangedEventHandler PropertyChanged = (s, e) => { };

		public event Action RequestClose = () => { };

		public void Activate()
		{
			timer = new DispatcherTimer {Interval = TimeSpan.FromSeconds(3)};
			timer.Tick += HandlerTimerTick;
			timer.Start();
		}

		private void HandlerTimerTick(object sender, EventArgs e)
		{
			timer.Stop();
			Execute.NowOrWhenBecomesTrue(() => IsMouseOver == false, () => RequestClose());
		}
	}
}