﻿using System;
using System.Collections.ObjectModel;

namespace NotificationsDemo
{
	public class NotificationManager
	{
		private readonly Random random = new Random();

		public NotificationManager()
		{
			Notifications = new ObservableCollection<NotificationViewModel>();
		}

		public void ShowNotification(string text)
		{
			var notificationViewModel = new NotificationViewModel {Text = text};
			notificationViewModel.RequestClose += () => Notifications.Remove(notificationViewModel);

			Notifications.Add(notificationViewModel);
		}

		public ObservableCollection<NotificationViewModel> Notifications { get; private set; }
	}
}