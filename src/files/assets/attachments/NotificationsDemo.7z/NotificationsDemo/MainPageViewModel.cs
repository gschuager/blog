﻿namespace NotificationsDemo
{
	public class MainPageViewModel
	{
		private int number;

		public MainPageViewModel()
		{
			NotificationManager = new NotificationManager();
		}

		public void ShowNotification()
		{
			NotificationManager.ShowNotification("Notification " + number++);
		}

		public NotificationManager NotificationManager { get; private set; }
	}
}